<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/logo-header.png");
td_demo_media::add_image_to_media_gallery('td_logo_footer',             "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/logo-other.png");
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/logo-other.png");


// other images
td_demo_media::add_image_to_media_gallery('td_pic_about',               "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/about.jpg");
td_demo_media::add_image_to_media_gallery('td_blog_cars_bg',            "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/bg.jpg");