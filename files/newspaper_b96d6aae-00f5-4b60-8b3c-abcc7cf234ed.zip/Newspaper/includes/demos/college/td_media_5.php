<?php
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/college/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_footer',             'http://demo_content.tagdiv.com/Newspaper_6/college/logo-footer.png');
td_demo_media::add_image_to_media_gallery('td_pic_homepage_big_ad',     'http://demo_content.tagdiv.com/Newspaper_6/college/big-ad.jpg');
td_demo_media::add_image_to_media_gallery('td_college_bg',              'http://demo_content.tagdiv.com/Newspaper_6/college/bg.jpg');