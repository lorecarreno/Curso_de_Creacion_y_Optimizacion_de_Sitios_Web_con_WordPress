<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('shop_professional',          'http://demo_content.tagdiv.com/Newspaper_multi/ink/shop_professional.jpg');

//the shop page
td_demo_media::add_image_to_media_gallery('testimonial1',            'http://demo_content.tagdiv.com/Newspaper_multi/ink/testimonial1.jpg');
td_demo_media::add_image_to_media_gallery('testimonial2',            'http://demo_content.tagdiv.com/Newspaper_multi/ink/testimonial2.jpg');
