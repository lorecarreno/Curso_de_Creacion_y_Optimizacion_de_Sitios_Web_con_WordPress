<?php
/**
 * Created by ra on 5/14/2015.
 */

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',              'http://demo_content.tagdiv.com/Newspaper_multi/law_firm/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',       'http://demo_content.tagdiv.com/Newspaper_multi/law_firm/logo-header@2x.png');

//homepage images
td_demo_media::add_image_to_media_gallery('td_hero_home',                "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/hero-home.jpg");
td_demo_media::add_image_to_media_gallery('td_section_care_clients',     "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/section-care-clients.jpg");

