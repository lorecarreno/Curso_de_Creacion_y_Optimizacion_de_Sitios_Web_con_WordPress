<?php

td_demo_media::add_image_to_media_gallery('interior1',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/int1.jpg");
td_demo_media::add_image_to_media_gallery('interior2',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/int2.jpg");
td_demo_media::add_image_to_media_gallery('interior3',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/interior3.jpg");
td_demo_media::add_image_to_media_gallery('interior4',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/interior4.jpg");
td_demo_media::add_image_to_media_gallery('people1',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/people1.jpg");
td_demo_media::add_image_to_media_gallery('people2',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/people2.jpg");
td_demo_media::add_image_to_media_gallery('people3',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/people3.jpg");
td_demo_media::add_image_to_media_gallery('people4',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/people4.jpg");
