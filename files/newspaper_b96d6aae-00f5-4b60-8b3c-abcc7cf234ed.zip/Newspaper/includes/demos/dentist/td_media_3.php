<?php

//gallery images
td_demo_media::add_image_to_media_gallery('gallery1',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery1.jpg");
td_demo_media::add_image_to_media_gallery('gallery2',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery2.jpg");
td_demo_media::add_image_to_media_gallery('gallery3',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery3.jpg");
td_demo_media::add_image_to_media_gallery('gallery4',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery4.jpg");
td_demo_media::add_image_to_media_gallery('gallery5',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery5.jpg");
td_demo_media::add_image_to_media_gallery('gallery6',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery6.jpg");
td_demo_media::add_image_to_media_gallery('gallery7',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery7.jpg");
td_demo_media::add_image_to_media_gallery('gallery8',                   "http://demo_content.tagdiv.com/Newspaper_multi/dentist/gallery8.jpg");